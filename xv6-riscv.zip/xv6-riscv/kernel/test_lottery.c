// test_lottery.c
#include "types.h"
#include "user.h"

int main() {
    int i, pid;

    // Create three processes with different numbers of tickets
    int tickets[3] = {3, 2, 1};

    for (i = 0; i < 3; i++) {
        pid = fork();
        if (pid < 0) {
            printf(1, "Fork failed\n");
        } else if (pid == 0) {
            settickets(tickets[i]);
            while (1) {
                // Do some work
            }
            exit();
        }
    }

    for (i = 0; i < 3; i++) {
        wait(0);
    }

    exit();
}
